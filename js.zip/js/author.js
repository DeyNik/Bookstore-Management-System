function txt1(){
		
		var t1="<br> Author desc1<br><br>";
			document.getElementById("t1").innerHTML=t1;
			document.getElementById("t1").style.color="white";
			document.getElementById("im1").style.filter="brightness(80%)";
}

function txt1a(){
		
		
			document.getElementById("t1").innerHTML="";

			document.getElementById("im1").style.filter="brightness(100%)";
}
function txt2(){
		
		var t1="<br> Author desc2<br><br>";
			document.getElementById("t2").innerHTML=t1;
			document.getElementById("t2").style.color="white";
			document.getElementById("im2").style.filter="brightness(80%)";
}

function txt2a(){
		
		
			document.getElementById("t2").innerHTML="";

			document.getElementById("im2").style.filter="brightness(100%)";
}
function txt3(){
		
		var t1="<br> Author desc3<br><br>";
			document.getElementById("t3").innerHTML=t1;
			document.getElementById("t3").style.color="white";
			document.getElementById("im3").style.filter="brightness(80%)";
}

function txt3a(){
		
		
			document.getElementById("t3").innerHTML="";

			document.getElementById("im3").style.filter="brightness(100%)";
}
function txt4(){
		
		var t1="<br> Author desc4<br><br>";
			document.getElementById("t4").innerHTML=t1;
			document.getElementById("t4").style.color="white";
			document.getElementById("im4").style.filter="brightness(80%)";
}

function txt4a(){
		
		
			document.getElementById("t4").innerHTML="";

			document.getElementById("im4").style.filter="brightness(100%)";
}
