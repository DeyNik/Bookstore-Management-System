
function changei1(){
	var i1=document.getElementById("img1");
	i1.src="picture/deli_b.png";
	}
function seti1(){
	var i1=document.getElementById("img1");
	i1.src="picture/deli_w.png";
	}
	
function changei2(){
	var i1=document.getElementById("img2");
	i1.src="picture/user_b.png";
	}
function seti2(){
	var i1=document.getElementById("img2");
	i1.src="picture/user_w.png";
	}
	
function changei3(){
	var i1=document.getElementById("img3");
	i1.src="picture/qual_b.png";
	}
function seti3(){
	var i1=document.getElementById("img3");
	i1.src="picture/qual_w.png";
	}
	
	