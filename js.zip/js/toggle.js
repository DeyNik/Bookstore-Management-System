function ab1(){
		//document.getElementById("a1").style.fontFamily="Noto Serif Korean";
		

		var a1="우리는 지식의 힘을 믿습니다. 그래서 우리의 목표는 그것을 공급하는 사람들을 돕고 그것을 갈망하는 사람들과 나누는 것입니다. 이것이 바로 우리가 취하는 모든 <br> 조치와 귀하의 모든 책 구매가 자금 조달에 도움이 되는 이유입니다.우리는 고객에게 매우 가치 <br>있는 경험을 제공하고, 고객이 자신의 행동을 자신의 가치에 맞추고 각 개인을 존중하고,성취에 대해 보상하고, 팀 성공을 축하할 수 있는 경험을 제공하기 위해 노력하고 있습니다.";

		if(document.getElementById("btn").innerHTML=="Korean"){
			document.getElementById("a1").innerHTML=a1;
			document.getElementById("btn").innerHTML="English";
		}
		else if(document.getElementById("btn").innerHTML=="English"){
			var a="We believe in the power of knowledge. So our goal is to help those who supply it <br>and share it with those who crave it.Which is why every action we take, and <br>every book purchase you make helps fund it. We are driven to provide customers with <br>a highly-valued experience, and one that allows them to align their actions with <br>their values and respect each individual, reward achievement, and celebrate team success.";
			document.getElementById("a1").innerHTML=a;
			document.getElementById("btn").innerHTML="Korean";
		
		}
		
	}