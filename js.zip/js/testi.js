var Quotes=["If you can't fly, run. If you can't run, walk. If you can't walk, crawl, but by all means, keep moving. <br>-Martin Luther King, Jr.",
 "Self-care is how you take your power back.<br> -Lalah Delia" ,
 "Happiness can be found even in the darkest of times, if one only remembers to turn on the light.<br> -Albus Dumbledore",
 "You don't have to control your thoughts. You just have to stop letting them control you.<br> -Dan Millman" 
 ,"Let your story go. Allow yourself to be present with who you are right now.<br> -Russ Kyle"];
 var curIndex = 0;

	setInterval(function slideShow() {
		document.getElementById('quote').innerHTML = Quotes[curIndex];
        curIndex++;
        if (curIndex == imgArray.length) { curIndex = 0; }		
    },2000);